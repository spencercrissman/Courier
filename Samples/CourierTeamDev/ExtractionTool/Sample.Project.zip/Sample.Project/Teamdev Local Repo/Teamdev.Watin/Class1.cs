﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using WatiN.Core;

namespace Teamdev.Watin
{

    [TestFixture]
    public class Class1
    {
        [Test]
        [STAThread]
        public void TestHomePage()
        {
            using(var browser = new IE("http://teamdev.stage"))
            {
                Assert.IsTrue(browser.ContainsText(("Buckley")));
            }
        }


        [Test]
        [STAThread]
        public void TestNewsPage()
        {
            using (var browser = new IE("http://teamdev.stage/news-and-events.aspx"))
            {
                Assert.IsTrue(browser.ContainsText(("CWS2")));
            }
        }


        
        [Test]
        [STAThread]
        public void TestSiteMapPage()
        {
            using (var browser = new IE("http://teamdev.stage/sitemap.aspx"))
            {
                Assert.IsTrue(browser.ContainsText(("Sitemap")));
            }
        }
    }
}
